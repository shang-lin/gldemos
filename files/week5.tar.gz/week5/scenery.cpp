/* scenery.cpp */

// Defines the non-inline methods of class Scene.

#ifdef WIN32
#include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <cmath>

#include "scenery.h"
#define sceneImageWidth 64
#define sceneImageHeight 64


//  This method draws the current scene.
//  args: SceneType s - The type of scene. Right now only the default
//                      is handled.
void Scene::draw() {
    GLfloat white_light[4] = {1.0f, 1.0f, 1.0f, 1.0f};

    // Texture mapping, ground.
    glPushMatrix();
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white_light);

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, texName[0]);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0); glVertex3fv(point0);
        glTexCoord2f(0.0, 1.0); glVertex3fv(point2);
        glTexCoord2f(1.0, 1.0); glVertex3fv(point4);
        glTexCoord2f(1.0, 0.0); glVertex3fv(point6);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glBegin(GL_POLYGON);
        glVertex3fv(point0);
        glVertex3fv(point6);
        glVertex3fv(point4);
        glVertex3fv(point2);
    glEnd();
    glPopMatrix();

    // Texture mapping, left wall
    glPushMatrix();
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white_light);

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, texName[1]);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0); glVertex3fv(point1);
        glTexCoord2f(0.0, 1.0); glVertex3fv(point3);
        glTexCoord2f(1.0, 1.0); glVertex3fv(point2);
        glTexCoord2f(1.0, 0.0); glVertex3fv(point0);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glBegin(GL_POLYGON);
        glVertex3fv(point0);
        glVertex3fv(point2);
        glVertex3fv(point3);
        glVertex3fv(point1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white_light);

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, texName[2]);

    // Draw texture for right wall.
    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0);
        glVertex3fv(point5);
        glTexCoord2f(0.0, 1.0);
        glVertex3fv(point7);
        glTexCoord2f(1.0, 1.0);
        glVertex3fv(point6);
        glTexCoord2f(1.0, 0.0);
        glVertex3fv(point4);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glBegin(GL_POLYGON);
        glVertex3fv(point4);
        glVertex3fv(point5);
        glVertex3fv(point7);
        glVertex3fv(point6);
    glEnd();
    glPopMatrix();

    // Texture mapping, far wall
    glPushMatrix();
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white_light);

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, texName[3]);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0); glVertex3fv(point3);
        glTexCoord2f(0.0, 1.0); glVertex3fv(point5);
        glTexCoord2f(1.0, 1.0); glVertex3fv(point4);
        glTexCoord2f(1.0, 0.0); glVertex3fv(point2);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glBegin(GL_POLYGON);
        glVertex3fv(point2);
        glVertex3fv(point3);
        glVertex3fv(point5);
        glVertex3fv(point4);
    glEnd();
    glPopMatrix();

    // Texture mapping, sky
    glPushMatrix();
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white_light);

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glBindTexture(GL_TEXTURE_2D, texName[4]);

    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0); glVertex3fv(point1);
        glTexCoord2f(0.0, 1.0); glVertex3fv(point3);
        glTexCoord2f(1.0, 1.0); glVertex3fv(point5);
        glTexCoord2f(1.0, 0.0); glVertex3fv(point7);
    glEnd();

    glDisable(GL_TEXTURE_2D);

    glPopMatrix();
}


//  This method sets up the bitmap arrays for a new scene.
void Scene::change() {
    int i, j;
    float c0, c1, c2;
    int g0, g1, g2, g3;

    float color1[3], color2[3], color3[3];

    switch(toggle) {
        case 0:
            // Ground is dark green.
            c0 = 0.0; c1 = 0.6 * 255.0; c2 = 0.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;
            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage1[i][j][0] = (GLubyte) g0;
                    sceneImage1[i][j][1] = (GLubyte) g1;
                    sceneImage1[i][j][2] = (GLubyte) g2;
                    sceneImage1[i][j][3] = (GLubyte) g3;
                }
            }
            // Sky is blue.
            c0 = 0.0; c1 = 0.0; c2 = 0.8 * 255.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;
            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage5[i][j][0] = (GLubyte) g0;
                    sceneImage5[i][j][1] = (GLubyte) g1;
                    sceneImage5[i][j][2] = (GLubyte) g2;
                    sceneImage5[i][j][3] = (GLubyte) g3;
                }
            }

            // Left wall is a mountain scene.

            modify3eltArray(color1, 0.3, 0.0, 0.3);
            modify3eltArray(color2, 0.6, 0.0, 0.6);
            modify3eltArray(color3, 0.9, 0.0, 0.9);

            makeMountains((float) 5.0, (float) 25.0, (float) 3.0,
                          (float) 23.0, (float) 50.0, (float) 6.0,
                          (float) 50.0, (float) 40.0, (float) 8.0,
                          color1, color2, color3, sceneImage2);




            // Left wall is a mountain scene.
            makeMountains((float) 30.0, (float) 25.0, (float) 7.0,
                          (float) 20.0, (float) 45.0, (float) 8.0,
                          (float)  50.0, (float) 30.0, (float) 8.0,
                          color1, color2, color3, sceneImage3);


            // The far wall is a mountain scene.
            makeMountains((float) 30.0, (float) 25.0, (float) 7.0,
                          (float) 20.0, (float) 45.0, (float) 8.0,
                          (float) 50.0, (float) 40.0, (float) 8.0,
                          color1, color2, color3,
                          sceneImage4);

            break;

        case 1:
            // Ground is golden.
            c0 = 250.0;
            c1 = 0.8 * 255.0;
            c2 = 0.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;

            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage1[i][j][0] = (GLubyte) g0;
                    sceneImage1[i][j][1] = (GLubyte) g1;
                    sceneImage1[i][j][2] = (GLubyte) g2;
                    sceneImage1[i][j][3] = (GLubyte) g3;
                }
            }

            // Sky is blue.
            c0 = 0.0;
            c1 = 0.0;
            c2 = 0.8 * 255.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;
            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage5[i][j][0] = (GLubyte) g0;
                    sceneImage5[i][j][1] = (GLubyte) g1;
                    sceneImage5[i][j][2] = (GLubyte) g2;
                    sceneImage5[i][j][3] = (GLubyte) g3;
                }
            }

            // Left wall is a mountain scene.
            modify3eltArray(color1, 0.3, 0.3, 0.0);
            modify3eltArray(color2, 0.6, 0.6, 0.0);
            modify3eltArray(color3, 0.8, 0.8, 0.0);

            makeMountains((float) 5.0, (float) 15.0, (float) 3.0,
                          (float) 23.0, (float) 30.0, (float) 6.0,
                          (float) 50.0, (float) 20.0, (float) 8.0,
                          color1, color2, color3, sceneImage2);


            // Right wall is a mountain scene.
            makeMountains((float) 30.0, (float) 15.0, (float) 7.0,
                          (float) 20.0, (float) 25.0, (float) 8.0,
                          (float) 50.0, (float) 20.0, (float) 8.0,
                          color1, color2, color3, sceneImage3);

            // The far wall is a mountain scene.
            makeMountains((float) 30.0, (float) 15.0, (float) 7.0,
                          (float) 20.0, (float) 25.0, (float) 8.0,
                          (float) 50.0, (float) 20.0, (float) 8.0,
                          color1, color2, color3, sceneImage4);
           break;
        case 2:
            // Ground is green.
            c0 = 0.0; c1 = 0.9 * 255.0; c2 = 0.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;
            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage1[i][j][0] = (GLubyte) g0;
                    sceneImage1[i][j][1] = (GLubyte) g1;
                    sceneImage1[i][j][2] = (GLubyte) g2;
                    sceneImage1[i][j][3] = (GLubyte) g3;
                }
            }

            // Left, right and far walls, and sky are blue.
            c0 = 0.0; c1 = 0.0; c2 = 0.7 * 255.0;
            g0 = (int) c0; g1 = (int) c1; g2 = (int) c2; g3 = 255;
            for (i = 0; i < sceneImageWidth; i++) {
                for (j = 0; j < sceneImageHeight; j++) {
                    sceneImage2[i][j][0] = (GLubyte) g0;
                    sceneImage2[i][j][1] = (GLubyte) g1;
                    sceneImage2[i][j][2] = (GLubyte) g2;
                    sceneImage2[i][j][3] = (GLubyte) g3;
                    sceneImage3[i][j][0] = (GLubyte) g0;
                    sceneImage3[i][j][1] = (GLubyte) g1;
                    sceneImage3[i][j][2] = (GLubyte) g2;
                    sceneImage3[i][j][3] = (GLubyte) g3;
                    sceneImage4[i][j][0] = (GLubyte) g0;
                    sceneImage4[i][j][1] = (GLubyte) g1;
                    sceneImage4[i][j][2] = (GLubyte) g2;
                    sceneImage4[i][j][3] = (GLubyte) g3;

                    sceneImage5[i][j][0] = (GLubyte) g0;
                    sceneImage5[i][j][1] = (GLubyte) g1;
                    sceneImage5[i][j][2] = (GLubyte) g2;
                    sceneImage5[i][j][3] = (GLubyte) g3;
                }
            }

            break;
        default:
            break;
    }
}




//  This method sets up the texture parameters and environment variables.
void Scene::setTextures() {
    glGenTextures(5, texName);

    // Scene, ground textures.
    glBindTexture(GL_TEXTURE_2D, texName[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, sceneImageWidth,
                 sceneImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 sceneImage1);
    glEnable(GL_TEXTURE_2D);

    // Scene, left wall texture.
    glBindTexture(GL_TEXTURE_2D, texName[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, sceneImageWidth,
                 sceneImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 sceneImage2);
    glEnable(GL_TEXTURE_2D);

    // Right wall texture.
    glBindTexture(GL_TEXTURE_2D, texName[2]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, sceneImageWidth,
                 sceneImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 sceneImage3);
    glEnable(GL_TEXTURE_2D);

    // Far wall texture.
    glBindTexture(GL_TEXTURE_2D, texName[3]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, sceneImageWidth,
                 sceneImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 sceneImage4);
    glEnable(GL_TEXTURE_2D);

    // Sky texture.
    glBindTexture(GL_TEXTURE_2D, texName[4]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, sceneImageWidth,
                 sceneImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 sceneImage5);
    glEnable(GL_TEXTURE_2D);
}


//  This method calculates the color values of pixels used for drawing a set
//  of 3 mountains and the sky above them.
//  args: float m1pos - x position of mountain 1's peak.
//        float m1height - Height of mountain 1.
//        float m1width - Half width of mountain 1.

//        The remaining arguments follow the same pattern for mountains
//        2 and 3.

//        float cfactor1[] - Array of color factors for the nearest mountain.
//                           These factors are multiplied by 255 to obtain
//                           the color of the mountain.
//        cfactor2 and cfactor3 are for the middle and far mountains.
//        GLubyte sceneImage[][][] - Array that holds the pixel colors.
void Scene::makeMountains(float m1pos, float m1height, float m1width,
                          float m2pos, float m2height, float m2width,
                          float m3pos, float m3height, float m3width,
                          float cfactor1[], float cfactor2[],
                          float cfactor3[],
                          GLubyte sceneImage[][sceneImageHeight][4])
{
    float m1y, m2y, m3y;
    int im1y, im2y, im3y;

    float c0, c1, c2;  // Color values;
    int ci0, ci1, ci2, ci3; // Color values in integer form.
    float x;
    int i, j;

    for (i = 0; i < sceneImageWidth; i++) {
        x = (float) i;
        m1y = mountain(x, m1pos, m1height, m1width);
        m2y = mountain(x, m2pos, m2height, m2width);
        m3y = mountain(x, m3pos, m3height, m3width);
        im1y = sceneImageHeight - (int) m1y;
        im2y = sceneImageHeight - (int) m2y;
        im3y = sceneImageHeight - (int) m3y;

        for (j = 0; j < sceneImageHeight; j++) {
            // Coloring mountains.
            if (j >= im1y || j >= im2y || j >= im3y) {
                // Mountain 3 is the farthest.
                /// j (the y coordinate) has to be
                //  within mountain 3's edge to be part
                //  of mountain 3.
                if (j >= im3y) {
                    c0 = cfactor1[0] * 255.0;
                    c1 = cfactor1[1] * 255.0;
                    c2 = cfactor1[2] * 255.0;
                }
                // Mountain 1 is in the middle.
                if (j >= im1y) {
                    c0 = cfactor2[0] * 255.0;
                    c1 = cfactor2[1] * 255.0;
                    c2 = cfactor2[2] * 255.0;
                }

                // Mountain 2 is the nearest.
                if (j >= im2y) {
                    c0 = cfactor3[0] * 255.0;
                    c1 = cfactor3[1] * 255.0;
                    c2 = cfactor3[2] * 255.0;
                }

                // Convert the colors to integers.
                ci0 = (int) c0;
                ci1 = (int) c1;
                ci2 = (int) c2;
                ci3 = 255;
            }
            // Color the sky above the mountains.
            else{
                c0 = 0.0; c1 = 0.0; c2 = 0.8 * 255.0;
                ci0 = (int) c0; ci1 = (int) c1; ci2 = (int) c2;
                ci3 = 255;
            }

            // Put the colors into the sceneImage array.
            sceneImage[i][j][0] = (GLubyte) ci0;
            sceneImage[i][j][1] = (GLubyte) ci1;
            sceneImage[i][j][2] = (GLubyte) ci2;
            sceneImage[i][j][3] = (GLubyte) ci3;

        }
    }
}


//  This method returns the value on a Gaussian distribution.
//  The Gaussian distribution approximates the shape of a mountain.
//  args: float x - x-coordinate of the current pixel.
//        float position -  X coordinate of mountain peak.
//        float halfwidth - Half width of mountain.
float Scene::mountain(float x, float position, float height,
                      float halfWidth)
{
    float tmp;
    tmp = (x - position) / (float) 2.0 / halfWidth;
    tmp = -tmp * tmp;
    tmp = height * exp(tmp);
    return tmp;

}


//  This method modifies the contents of a 3 element array.
void Scene::modify3eltArray(float a[], float v1, float v2,
                            float v3)
{
    a[0] = v1;
    a[1] = v2;
    a[2] = v3;
}
