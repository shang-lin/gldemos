/* scenery.h */

// This file declares class Scene.

#ifndef _SCENERY_H_
#define _SCENERY_H_

#define sceneImageWidth 64
#define sceneImageHeight 64

//  This class represents the background scenery in the Roboviewer window.
class Scene{
public:
    enum SceneType{DEFAULT, DESERT, GRASS};
    GLuint texName[5];
    Scene();

    void change();
    void draw();

    float mountain(float x, float position,
                   float height, float halfWidth);

private:
    int toggle;

    // 8 corner points to define the scenes.
    float point0[3], point1[3], point2[3], point3[3];
    float point4[3], point5[3], point6[3], point7[3];

    SceneType current_scene;  // current scene
    GLubyte sceneImage1[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage2[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage3[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage4[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage5[sceneImageWidth][sceneImageHeight][4];

    void makeMountains(float m1pos, float m1height, float m1width,
                        float m2pos, float m2height, float m2width,
                        float m3pos, float m3height, float m3width,
                        float cfactor1[], float cfactor2[], float cfactor3[],
                        GLubyte sceneImage[][sceneImageHeight][4]);
    void modify3eltArray(float a[], float v1, float v2, float v3);

public:
    int getToggle() { return toggle; }
    void setToggle(int t) { toggle = t; }
    void setTextures();
    void setCurrentScene(SceneType cs) { current_scene = cs; }

};



//  The default constructor initializes the scene type to the default.
inline Scene::Scene() {
    current_scene = DEFAULT;
    toggle = 0;

    point0[0] = -50.0;
    point0[1] = -50.0;
    point0[2] = 50.0;

    point1[0] = -50.0;
    point1[1] = 50.0;
    point1[2] = 50.0;

    point2[0] = -50.0;
    point2[1] = -50.0;
    point2[2] = -50.0;

    point3[0] = -50.0;
    point3[1] = 50.0;
    point3[2] = -50.0;

    point4[0] = 50.0;
    point4[1] = -50.0;
    point4[2] = -50.0;

    point5[0] = 50.0;
    point5[1] = 50.0;
    point5[2] = -50.0;

    point6[0] = 50.0;
    point6[1] = -50.0;
    point6[2] = 50.0;

    point7[0] = 50.0;
    point7[1] = 50.0;
    point7[2] = 50.0;
}


#endif

