/* robot.cpp */

// Defines methods of class Robot.

#include <stdio.h>
#include <GL/glut.h>
#include <iostream>
#include <cmath>
#include <cassert>

#include "robot.h"

using namespace std;


//  This constructor initializes all the data members to 0 or NULL and the
//  rotation axis to the y axis.
Robot::Robot() {
    angle = 0.0f;
    x_pos = 0.0f;
    y_pos = 0.0f;
    z_pos = 0.0f;
    csign = 1.0f;

    xrot_angle = 0.0f;
    yrot_angle = 0.0f;

    texName = NULL;
    texture_flag = 0;
}


//  The angle between the torso and each leg, the
//  starting positions, and the angle of rotation
//  are initialized.
Robot::Robot(GLfloat a = 0.0f, GLfloat x = 0.0f, GLfloat y = 0.0f,
             GLfloat z = 0.0f)
{
    // Make sure that the angle is non-negative.
    assert(a >= 0.0f);

    // Set the angle and the coordinates.
    angle = a;
    x_pos = x;
    y_pos = y;
    z_pos = z;
    xrot_angle = 0.0f;
    yrot_angle = 0.0f;
}



//  Robot::drawTorso().
//  This method draws the robot's torso as a green
//  3x5x2 cube.
void Robot::drawTorso() {
    GLfloat green_light[4] = {0.5f, 1.0f, 0.5f, 1.0f};

    glPushMatrix();
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, green_light);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, green_light);
        glScalef(3.0f, 5.0f, 2.0f);

        // Texture mapping.
        glPushMatrix();
        glEnable(GL_TEXTURE_2D);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glBindTexture(GL_TEXTURE_2D, texName[0]);

        glBegin(GL_QUADS);
        glNormal3f(0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0, 0.0);
        glVertex3f(-0.5 * 2.0, -0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(-0.5 * 2.0, 0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(0.5 * 2.0, 0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(0.5 * 2.0, -0.5 * 2.0, 0.5 * 2.0);

        glEnd();

        glDisable(GL_TEXTURE_2D);
        glPopMatrix();

        drawCube(2.0);
    glPopMatrix();
}


//  This method draws the robot's head as a red 2x2x2
//  cube.
void Robot::drawHead() {
    GLfloat red_light[4] = {1.0f, 0.0f, 0.0f, 1.0f};
    glPushMatrix();
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, red_light);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, red_light);
        glTranslatef(0.0f, 7.0f, 0.0f);
        glScalef(2.0f, 2.0f, 2.0f);

        // Texture mapping.
        // glPushMatrix();
        glEnable(GL_TEXTURE_2D);

        // glTexEnvi(GL_TEXTURE_2D, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

        glBindTexture(GL_TEXTURE_2D, texName[1]);


        glBegin(GL_QUADS);

        glNormal3f(0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0, 0.0);
        glVertex3f(-0.5 * 2.0, -0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(-0.5 * 2.0, 0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(1.0, 1.0);
        glVertex3f(0.5 * 2.0, 0.5 * 2.0, 0.5 * 2.0);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(0.5 * 2.0, -0.5 * 2.0, 0.5 * 2.0);

        glEnd();
        glDisable(GL_TEXTURE_2D);
        // glPopMatrix();

        drawCube(2.0);

    glPopMatrix();

}


//  This method draws the robot's legs. Each leg is a
//  blue 1x5x1 cube.
void Robot::drawLegs() {
    GLfloat blue_light[4]={0.0f, 0.0f, 1.0f, 1.0f};
    glPushMatrix();

        // Draw first leg.
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, blue_light);
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, blue_light);
            glTranslatef(-2.0f, -3.8f, 0.0f);
            glRotatef(angle, 1.0, 0.0, 0.0);
            glTranslatef(0.0f, -5.0f, 0.0f);
            glScalef(0.8f, 5.0f, 0.8f);
            drawCube(2.0);
        glPopMatrix();

        // Draw second leg relative to first.
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, blue_light);
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, blue_light);
            glTranslatef(2.0f, -3.8f, 0.0f);
            glRotatef(-angle, 1.0, 0.0, 0.0);
            glTranslatef(0.0f, -5.0f, 0.0f);
            glScalef(0.8f, 5.0f, 0.8f);
            drawCube(2.0);
        glPopMatrix();

    glPopMatrix();
}


void Robot::drawArms() {
    GLfloat yellow_light[4] = {1.0f, 1.0f, 0.0f, 1.0f};

    glPushMatrix();
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, yellow_light);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, yellow_light);

        // Draw the left arm.
        glPushMatrix();
            glTranslatef(-4.0f, 0.7f, 0.2f);
            glTranslatef(0.0f, 4.0f, 0.0f);
            glRotatef(angle, 1.0f, 0.0f, 0.0f);
            glTranslatef(0.0f, -4.0f, 0.0f);
            glScalef(0.7f, 4.0f, 1.0f);
            drawCube(2.0);
         glPopMatrix();

        // Draw the right arm.
        glPushMatrix();
            glTranslatef(4.0f, 1.0f, 0.2f);
            glTranslatef(0.0f, 4.0f, 0.0f);
            glRotatef(-angle, 1.0f, 0.0f, 0.0f);
            glTranslatef(0.0f, -4.0f, 0.0f);
            glScalef(0.7f, 4.0f, 1.0f);
            drawCube(2.0);
        glPopMatrix();
    glPopMatrix();
}



//  This method draws the entire robot by calling each of the
//  methods to draw each part of the robot.

void Robot::draw() {

    // Set up the robot in the correct orientation.
    setup();

    // Draw all parts of the robot.
    glPushMatrix();
	drawTorso();
    drawHead();
    drawArms();
    drawLegs();
	glPopMatrix();

}


//  This method performs the initial transformations to draw the
//  robot in the correct location and orientation.
void Robot::setup() {
    if (angle > 20.0)
        csign = -1.0;
    else if (angle < -20.0)
        csign = 1.0;

    angle = angle + 0.3 * csign;

    x_pos = x_pos + 0.05 * sin(yrot_angle / 180.0 * 3.1416);
    z_pos = z_pos + 0.05 * cos(yrot_angle / 180.0 * 3.1416);

    glTranslatef(x_pos, y_pos, z_pos);
    glRotatef(xrot_angle, 1.0f, 0.0f, 0.0f);
    glRotatef(yrot_angle, 0.0f, 1.0f, 0.0f);
}


int Robot::incrementRotation(char axis, GLfloat increment) {
    switch(axis) {
        case 'x':
            xrot_angle += increment;
            break;
        case 'y':
            yrot_angle = yrot_angle + increment;
            break;
        default:
            return -1;
    }

    return 0;
}



//  This method draws a cube using six polygons.
//  args: doubel size - Distance between two opposite faces of the cube.
void Robot::drawCube(double size) {

    // Front face.
    glBegin(GL_POLYGON);
    glNormal3f(0.0, 0.0, 1.0);
    glVertex3f(-0.5 * size, -0.5 * size, 0.5 * size);
    glVertex3f(0.5 * size, -0.5 * size, 0.5 * size);
    glVertex3f(0.5 * size, 0.5 * size, 0.5 * size);
    glVertex3f(-0.5 * size, 0.5 * size, 0.5 * size);
    glEnd();

    glBegin(GL_POLYGON);
        glNormal3f(0.0, 0.0, -1.0);
        glVertex3f(-0.5 * size, -0.5 * size, -0.5 * size);
        glVertex3f(-0.5 * size, 0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, 0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, -0.5 * size, -0.5 * size);
    glEnd();

    glBegin(GL_POLYGON);
        glNormal3f(1.0, 0.0, 0.0);
        glVertex3f(0.5 * size, -0.5 * size, 0.5 * size);
        glVertex3f(0.5 * size, -0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, 0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, 0.5 * size, 0.5 * size);
    glEnd();

    glBegin(GL_POLYGON);
        glNormal3f(-1.0, 0.0, 0.0);
        glVertex3f(-0.5 * size, -0.5 * size, 0.5 * size);
        glVertex3f(-0.5 * size, 0.5 * size, 0.5 * size);
        glVertex3f(-0.5 * size, 0.5 * size, -0.5 * size);
        glVertex3f(-0.5 * size, -0.5 * size, -0.5 * size);
    glEnd();

    glBegin(GL_POLYGON);
        glNormal3f(0.0, 1.0, 0.0);
        glVertex3f(-0.5 * size, 0.5 * size, 0.5 * size);
        glVertex3f(0.5 * size, 0.5 * size, 0.5 * size);
        glVertex3f(0.5 * size, 0.5 * size, -0.5 * size);
        glVertex3f(-0.5 * size, 0.5 * size, -0.5 * size);
    glEnd();

    glBegin(GL_POLYGON);
        glNormal3f(0.0, -1.0, 0.0);
        glVertex3f(-0.5 * size, -0.5 * size, 0.5 * size);
        glVertex3f(-0.5 * size, -0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, -0.5 * size, -0.5 * size);
        glVertex3f(0.5 * size, -0.5 * size, 0.5 * size);
    glEnd();
}


//    This method initializes the values in checkImage to create
//    the texture on the robot's torso.
void Robot::makeTorsoTexture(void) {
    int i, j, k, c;

    assert((texture_flag == 0) || (texture_flag == 1));

    if (texture_flag == 0) {
        // Make a green background. Every pixel is green.
        for (i = 0; i < ImageHeight; i++) {
            for (j = 0; j < ImageWidth; j++) {
                for (k = 0; k < 4; k++) {
                    checkImage[i][j][k] = 0;
                    if (k == 3 || k == 1)
                        checkImage[i][j][k] = 255;
                }
            }
        }

        // Draw cloth pattern.
        for (i = 0; i < ImageHeight; i++) {
            for (j = 24; j < 39; j++) {
               if (j < 36 && j >= 27)
                   checkImage[i][j][0] = 255;
               if ((i < 12 && i >= 4) || (i < 28 && i >= 20)
                    || (i < 44 && i >= 36) || (i < 60 && i >= 52))
                   checkImage[i][j][1]=0;
            }

        }
    }
    // Checker board pattern.
    else if (texture_flag == 1) {
        for (i = 0; i < ImageHeight; i++) {
            for (j = 0; j < ImageWidth; j++) {
                // From OpenGL Reference Manual.
                c = ((((i & 0x8) == 0)^((j & 0x8) == 0))) * 255;
                checkImage[i][j][0] = (GLubyte) c;
                checkImage[i][j][1] = (GLubyte) c;
                checkImage[i][j][2] = (GLubyte) c;
                checkImage[i][j][3] = (GLubyte) 255;
            }
        }
    }

}


//  This method sets up the face texture for the robot's head.
//  TODO: Make texture appear on face.
void Robot::makeFaceTexture() {
//    glGenTextures(2, &texName);
//    glBindTexture(GL_TEXTURE_2D, texName);

    int i, j;
    // Face pattern.

    for (i = 0; i < ImageHeight; i++) {
        for (j = 0; j < ImageWidth; j++) {
            // Circle is (x-a)^2 + (y-b)^2 = r^2.
            // a is 22, y is 42, radius is 4.
            // Mouth is a 4 x 32 rectangle.
            if ((((j - 22) * (j - 22) + (i - 42) * (i - 42)) <= 16)
                 || (((j - 42) * (j - 42) + (i - 42) * (i - 42)) <= 16)
                 || ( (j >= 16 && j <= 48) && (i >= 26 && i <= 30)))
            {
                 face_image[i][j][0] = 0;
                 face_image[i][j][1] = 255;
                 face_image[i][j][2] = 0;
                 face_image[i][j][3] = 255;
             }
             else{
                 // Red background.
                 face_image[i][j][0] = 255;
                 face_image[i][j][1] = 0;
                 face_image[i][j][2] = 0;
                 face_image[i][j][3] = 255;
             }
         }
    }



}


//  This method toggles the current texture on the robot's torso.
void Robot::toggleTexture() {
    texture_flag++;
    texture_flag = texture_flag % 2;
}


//  This method generates texture objects.
//  Texture objects allow multiple textures to
//  be defined simultaneously.
void Robot::genTextures(int num_textures) {
    texName = new GLuint[num_textures];

    assert(texName != NULL);
    glGenTextures(num_textures, texName);
}


//  This method sets up the environment variables and parameters
//  for a texture.
//  args: TextureType type - Indicates whether the texture is for
//                           the face or the torso.
void Robot::setupTexture(TextureType type) {
    assert(texName + type != NULL);

    glBindTexture(GL_TEXTURE_2D, texName[type]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    // glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    if (type == FACE) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ImageWidth,
                     ImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                     face_image);
    }
    else{
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ImageWidth,
                     ImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                     checkImage);
    }
}


//  Destructor.
Robot::~Robot() {
    if (texName != NULL)
        delete[] texName;
}


