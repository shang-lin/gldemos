/* textures.cpp */

// This program renders a 3D robot in OpenGL and adds textures to it.

#ifdef WIN32
#include <windows.h>
#endif

#include <GL/glut.h>
#include <assert.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "robot.h"
#include "scenery.h"
#include "bitmap.h"

using namespace std;

void render();
void resize(GLsizei w, GLsizei h);
void initialize();
void handleKeystroke(int key, int x, int y);

// Global variables.
static Robot *robot = NULL;
static Scene *background = NULL;
BITMAPINFO *BitmapInfo; // Bitmap information.

GLubyte *BitmapBitsA;
GLubyte *BitmapBitsB;

// Window size.
int xresol, yresol;
int Width;  /* Width of window */
int Height; /* Height of window */


//  Main function.
int main(int argc, char *argv[])
{
    robot = new Robot();
    background = new Scene();

    xresol = 500; yresol = 500;

    // Set the display mode.
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    // Create a 500 x 500 window.
    glutInitWindowSize(500, 500);
    glutCreateWindow("RoboViewer");

    initialize();

    // Set the OpenGL callback functions.
    // render() will be called whenever glutDisplayFunc is
    // needed, and resize(w, h) will be called whenever
    // glutReshapeFunc is needed. glutSpecialFunc is called whenever
    // a non-ASCII key is pressed.
    glutReshapeFunc(resize);
    glutDisplayFunc(render);

    glutIdleFunc(render);
    glutSpecialFunc(handleKeystroke);

    glutMainLoop();
    if (BitmapInfo)
    {
        free(BitmapInfo);
        free(BitmapBitsA);
        free(BitmapBitsB);
    }

    delete robot;
    delete background;

    return 0;
}


//  This function is called whenever the window is redrawn.
//  All it does is draw a robot and the background.
void render() {

    resize(xresol, yresol);

    // Clear the window and draw the robot.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Set up the camera.
    gluLookAt(0.0, 10.0, 40.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    GLfloat light_pos[4] = {0.0f, 0.0f, 10.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_POSITION, light_pos);

    assert(background != NULL);

    // Draw the background.
    background->draw();

    assert(robot != NULL);

    // Draw the robot
    glPushMatrix();
    robot->draw();
    glPopMatrix();


    // Clear the OpenGL pipeline and execute all waiting
    // commands.
    glutSwapBuffers();

}


//  This function is called whenever the window is resized
//  or maximized. It sets up the orthographic projection and
//  the viewport.

//  args: GLsizei w - Window width.
//	  GLsizei h - Window height.
void resize(GLsizei w, GLsizei h) {

    Width = w; Height = h;


    // Set the viewport to cover the entire window.
    glViewport(0, 0, w, h);

    // Prevent division by 0.
    if (h == 0)
        h = 1;
    if (w == 0)
        w = 1;

    // Reset the projection matrix to the identity matrix.
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    GLdouble aspect = (GLdouble)w / (GLdouble)h;
    gluPerspective(65.0, aspect, 1.0, 129.0);

    // Reset the modelview matrix to the identity matrix.
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


//  This method initializes OpenGL's lighting and material
//  settings.
void initialize() {

    // Allow lighting and materials to have an effect.
    // By default, this is turned off. Once it is turned on,
    // lights and materials must be set for anything to appear.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3f(1.0f, 1.0f, 1.0f);
    glPolygonMode(GL_FRONT, GL_FILL);

    // Set shading model and enable lights.
    glShadeModel(GL_SMOOTH);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);

    // Turn on color tracking. This allows material properties
    // to be set using glColor.
    glEnable(GL_DEPTH_TEST);


    // Texture related commands.
    // glGenTextures(5, robot->texture_objects);

    robot->makeTorsoTexture();
    robot->makeFaceTexture();

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    robot->genTextures(2);

    robot->setupTexture(Robot::FACE);
    robot->setupTexture(Robot::TORSO);

    glEnable(GL_TEXTURE_2D);


    BitmapBitsA = LoadDIBitmap("pot.bmp", &BitmapInfo);
    background->setBitmapBitsA(BitmapBitsA);
    background->setBitmapWidthA(BitmapInfo->bmiHeader.biWidth);
    background->setBitmapHeightA(BitmapInfo->bmiHeader.biHeight);

    BitmapBitsB = LoadDIBitmap("sky.bmp", &BitmapInfo);
    background->setBitmapBitsB(BitmapBitsB);
    background->setBitmapWidthB(BitmapInfo->bmiHeader.biWidth);
    background->setBitmapHeightB(BitmapInfo->bmiHeader.biHeight);


    background->setTexturesB();

    // Lighting related commands.
    GLfloat ambient_light[] = {0.5f, 0.5f, 0.5f, 1.0f};
    GLfloat diffuse_light[] = {1.0f, 1.0f, 1.0f, 1.0f};

    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient_light);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_light);

}


//  This function is called when a non-ASCII key is pressed.
//  Only the direction arrows are handled. The direction
//  arrows indicate around which axis to rotate the robot.

//  args: int key - Which key is pressed.
//        int x - x coordinate of mouse.
//        int y - y coordinate of mouse.
void handleKeystroke(int key, int x, int y) {
    const GLfloat increment = 15.0f;
    if (key == GLUT_KEY_LEFT) {
        // Left arrow rotates robot around negative y axis.
        robot->incrementRotation('y', -increment);
    }
    else if (key == GLUT_KEY_RIGHT) {
        // Right arrow rotates robot around positive y axis.
        robot->incrementRotation('y', increment);
    }
    else if (key == GLUT_KEY_F1) {
        // If F1 is pressed, change the texture on the robot's body.
        robot->toggleTexture();
        robot->makeTorsoTexture();
        robot->setupTexture(Robot::TORSO);
    }
    else if (key == GLUT_KEY_F2){
        // If F2 is pressed, change the background texture.

        // Change the value of background->toggle.
        int t = background->getToggle();
        t++;
        t = t % 4;
        background->setToggle(t);

        // Change the scene.
        if ( t < 3){
            if (t == 0){
                background->setCurrentScene(Scene::DEFAULT);
            }
            else if (t == 1){
                background->setCurrentScene(Scene::GRASS);
            }
            else if (t == 2){
                background->setCurrentScene(Scene::GRASS);
            }
            background->change();
            background->setTextures();
        }

        else {
            background->setTexturesB();
        }
    }
    glutPostRedisplay();
}


