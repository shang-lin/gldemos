#ifndef _ROBOT_H_
#define _ROBOT_H_

// For Windows only.
#ifdef WIN32
#include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <assert.h>

#define ImageWidth 64
#define ImageHeight 64



//  This class represents a 3D robot with a head, a torso,
//  and two legs.
class Robot{


private:
    // Data members.
    GLfloat angle;       // This is the angle between the robot's
                         // legs and its torso when the robot walks.
    GLfloat csign;

    // These are the angles by which the robot is rotated about
    // the x and y axes.
    GLfloat xrot_angle;
    GLfloat yrot_angle;

    int texture_flag;
    int num_textures;
    GLuint *texName;

    // These are the coordinates where the robot will be
    // drawn.
    GLfloat x_pos, y_pos, z_pos;


public:
    GLubyte face_image[ImageHeight][ImageWidth][4];
    enum TextureType{ TORSO, FACE };

private:
    void drawTorso();    // Draws the robot's upper body.
    void drawLegs();     // Draws the robot's legs.
    void drawHead();     // Draws the robot's head.
    void drawArms();
    void drawCube(double size); // Draw a unit cube centered on the origin


    void setup();        // Sets up the location where


public:
    Robot();
    Robot(GLfloat a,     // Constructor sets the angle and
          GLfloat x,     // the x, y, z starting coordinates.
          GLfloat y,
          GLfloat z);

    void draw();                // Draws the robot.
    void makeTorsoTexture(void);  // Makes texture patterns for robot's torso.
    void makeFaceTexture(); // Draws texture onto the robot's face.

    void toggleTexture();

    GLubyte checkImage[ImageHeight][ImageWidth][4];

    // Increments angles of rotationof the torso.
    int incrementRotation(char axis, GLfloat incr);

    void genTextures(int num_textures);
    void setupTexture(TextureType type);
    ~Robot();
};



#endif

