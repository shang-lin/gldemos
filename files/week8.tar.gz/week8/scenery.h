/* scenery.h */

// This file declares class Scene.

#ifndef _SCENERY_H_
#define _SCENERY_H_

#include <iostream>


using namespace std;

#define sceneImageWidth 64
#define sceneImageHeight 64


//  This class represents the background scenery in the Roboviewer window.
class Scene{
public:
   // enum SceneType{DEFAULT, DESERT, GRASS};
    Scene();

    void change();
    void draw();
    
private:
    int current_scene;
    GLuint texName[6];
    
    // 8 corner points to define the scenes.
    float point0[3], point1[3], point2[3], point3[3];
    float point4[3], point5[3], point6[3], point7[3];

    // Bitmap arrays for manually drawn textures.
    GLubyte sceneImage1[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage2[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage3[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage4[sceneImageWidth][sceneImageHeight][4];
    GLubyte sceneImage5[sceneImageWidth][sceneImageHeight][4];

    // Bitmap file data. 3 possible bitmap files.
    GLubyte *BitmapBitsA;
    GLuint BitmapWidthA;
    GLuint BitmapHeightA;
    GLubyte *BitmapBitsB;
    GLuint BitmapWidthB;
    GLuint BitmapHeightB;
    GLubyte *BitmapBitsC;
    GLuint BitmapWidthC;
    GLuint BitmapHeightC;

    // Fog vars.
    GLfloat fog_density; 
    static GLfloat fog_incr;   // Increment or decrement for fog density.
    int fog_switch; // Flag indicates whether fog is on.
    static GLfloat start_density;
    bool dcue_allowed;
    
    void makeMountains(float m1pos, float m1height, float m1width,
                        float m2pos, float m2height, float m2width,
                        float m3pos, float m3height, float m3width,
                        float cfactor1[], float cfactor2[], float cfactor3[],
                        GLubyte sceneImage[][sceneImageHeight][4]);
    void modify3eltArray(float a[], float v1, float v2, float v3);

    float mountain(float x, float position,
                   float height, float halfWidth);
    void setDepthCue(GLfloat colors[]);
    
public:
    //  This method toggles the fog switch.s
    void toggleFog() {
        fog_switch ++;
        fog_switch %= 2;
    }
    
    int getCurrSceneID() const { return current_scene; }
    void setTextures();
    void setTexturesB();
    void setCurrentScene(int cs) { 
        assert((cs >=0) && (cs < 4));
        current_scene = cs; 
    }

    void loadBitmapTextures();
    
    //  Decrements fog density.
    void decrFogDensity() {
        fog_density -= fog_incr;
        cout<<"fog density: "<<fog_density<<endl;
    }
    
    //  Increments fog density.
    void incrFogDensity() {
        fog_density += fog_incr;
        cout<<"fog density: "<<fog_density<<endl;
    }
    
    //  Returns true if fog mode is on,
    //  false otherwise.
    bool fogOn() const {
        return (fog_switch == 0);
    }
    
    void toggleDepthCue() {
        dcue_allowed = !dcue_allowed;
    }
    
    bool depthCueAllowed() const {
        return dcue_allowed;
    }
    
    ~Scene();
};


#endif

